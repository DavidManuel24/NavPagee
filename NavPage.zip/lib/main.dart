import 'package:flutter/material.dart';
import 'pageone.dart';
import 'pagetwo.dart';
import 'pagethree.dart';
import 'pagefour.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Rutas Nombradas',
    theme: ThemeData(
        appBarTheme: const AppBarTheme(
      color: Color(0xff69be9b),
    )),
    // Inicie la aplicación con la ruta con nombre. En nuestro caso, la aplicación comenzará
    // en el Widget FirstScreen
    initialRoute: '/',
    routes: {
      // Cuando naveguemos hacia la ruta "/", crearemos el Widget FirstScreen
      '/': (context) => FirstScreen(),
      // Cuando naveguemos hacia la ruta "/second", crearemos el Widget SecondScreen
      '/Segunda': (context) => SecondScreen(),
      '/Tercera': (context) => ThirdScreen(),
      '/Cuarta': (context) => FourScreen(),
    },
  ));
}
